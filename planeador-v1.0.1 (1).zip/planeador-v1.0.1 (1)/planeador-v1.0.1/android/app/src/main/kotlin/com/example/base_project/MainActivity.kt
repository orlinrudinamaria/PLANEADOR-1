package com.example.base_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
