class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Welcome  images
  static String imgObject11 = '$imagePath/img_object_1_1.png';

  static String imgCalt1 = '$imagePath/img_calt_1.png';

  // Login page images
  static String imgMdihide = '$imagePath/img_mdihide.svg';

  // Sign up page images
  static String imgEye = '$imagePath/img_eye.svg';

  // Home page images
  static String imgMenu = '$imagePath/img_menu.png';

  static String imgRectangle13 = '$imagePath/img_rectangle_13.png';

  static String imgRectangle12 = '$imagePath/img_rectangle_12.png';

  static String imgRectangle15 = '$imagePath/img_rectangle_15.png';

  static String imgRectangle14 = '$imagePath/img_rectangle_14.png';

  static String imgRectangle16 = '$imagePath/img_rectangle_16.png';

  static String imgRectangle17 = '$imagePath/img_rectangle_17.png';

  static String imgRectangle19 = '$imagePath/img_rectangle_19.png';

  static String imgRectangle20 = '$imagePath/img_rectangle_20.png';

  static String imgRectangle23 = '$imagePath/img_rectangle_23.png';

  static String imgRectangle25 = '$imagePath/img_rectangle_25.png';

  static String imgRectangle26 = '$imagePath/img_rectangle_26.png';

  // fine arts images
  static String imgRectangle26122x152 =
      '$imagePath/img_rectangle_26_122x152.png';

  static String imgRectangle27 = '$imagePath/img_rectangle_27.png';

  static String imgRectangle28 = '$imagePath/img_rectangle_28.png';

  static String imgRectangle29 = '$imagePath/img_rectangle_29.png';

  static String imgRectangle30 = '$imagePath/img_rectangle_30.png';

  static String imgRectangle31 = '$imagePath/img_rectangle_31.png';

  static String imgRectangle32 = '$imagePath/img_rectangle_32.png';

  // nss images
  static String imgRectangle261 = '$imagePath/img_rectangle_26_1.png';

  static String imgRectangle27122x152 =
      '$imagePath/img_rectangle_27_122x152.png';

  static String imgRectangle28122x152 =
      '$imagePath/img_rectangle_28_122x152.png';

  static String imgRectangle29122x152 =
      '$imagePath/img_rectangle_29_122x152.png';

  static String imgRectangle30122x152 =
      '$imagePath/img_rectangle_30_122x152.png';

  static String imgRectangle31122x152 =
      '$imagePath/img_rectangle_31_122x152.png';

  static String imgRectangle32122x152 =
      '$imagePath/img_rectangle_32_122x152.png';

  // literary club images
  static String imgRectangle262 = '$imagePath/img_rectangle_26_2.png';

  static String imgRectangle271 = '$imagePath/img_rectangle_27_1.png';

  static String imgRectangle281 = '$imagePath/img_rectangle_28_1.png';

  static String imgRectangle291 = '$imagePath/img_rectangle_29_1.png';

  static String imgRectangle301 = '$imagePath/img_rectangle_30_1.png';

  static String imgRectangle311 = '$imagePath/img_rectangle_31_1.png';

  static String imgRectangle321 = '$imagePath/img_rectangle_32_1.png';

  // eco club images
  static String imgRectangle263 = '$imagePath/img_rectangle_26_3.png';

  static String imgRectangle272 = '$imagePath/img_rectangle_27_2.png';

  static String imgRectangle282 = '$imagePath/img_rectangle_28_2.png';

  static String imgRectangle292 = '$imagePath/img_rectangle_29_2.png';

  static String imgRectangle302 = '$imagePath/img_rectangle_30_2.png';

  static String imgRectangle312 = '$imagePath/img_rectangle_31_2.png';

  static String imgRectangle322 = '$imagePath/img_rectangle_32_2.png';

  // Frame Three images
  static String imgObject12 = '$imagePath/img_object_1_2.png';

  static String imgThumbsUp = '$imagePath/img_thumbs_up.svg';

  static String imgLock = '$imagePath/img_lock.svg';

  static String imgCalendar = '$imagePath/img_calendar.svg';

  static String imgClose = '$imagePath/img_close.svg';

  static String imgTelevision = '$imagePath/img_television.svg';

  static String imgAirplane = '$imagePath/img_airplane.svg';

  static String imgProfile = '$imagePath/img_profile.svg';

  static String imgVector = '$imagePath/img_vector.svg';

  static String imgForward = '$imagePath/img_forward.svg';

  static String imgLockOnerrorcontainer =
      '$imagePath/img_lock_onerrorcontainer.svg';

  static String imgArrowDown = '$imagePath/img_arrow_down.svg';

  // Common images
  static String imgArrowLeft = '$imagePath/img_arrow_left.svg';

  static String imgLogosfacebook = '$imagePath/img_logosfacebook.svg';

  static String imgFlatcoloriconsgoogle =
      '$imagePath/img_flatcoloriconsgoogle.svg';

  static String imgArrowLeftOnerrorcontainer =
      '$imagePath/img_arrow_left_onerrorcontainer.svg';

  static String imgAddImage = '$imagePath/img_add_image.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
