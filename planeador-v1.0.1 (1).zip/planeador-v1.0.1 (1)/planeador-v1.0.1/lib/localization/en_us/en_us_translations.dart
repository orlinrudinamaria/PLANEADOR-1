final Map<String, String> enUs = {
  // Welcome  Screen
  "lbl_get_started": "Get Started",
  "msg_let_s_explore_for": "Let’s explore for more events",

  // Login page Screen
  "lbl_login_now": "Login Now",
  "msg_don_t_have_an_account": "Don’t have an account ?",

  // Sign up page Screen
  "lbl_signup_now": "SignUp Now",

  // Home page Screen
  "lbl_clubs": "        CLUBS",

  // fine arts Screen
  "msg_event_date_xx_x":
      "Event date:xx/xx/xxxx\nTime:\nVenue: Auditorium\nForm:",
  "msg_event_date_xx_x2":
      "Event date:xx/xx/xxxx\nTime:\nVenue: Auditorium\n Form:",
  "msg_event_date_xx_xx_xxxx_time":
      "Event date:xx/xx/xxxx\nTime: 1:00 pm\nVenue: Auditorium\nForm: ",
  "msg_event_date_xx_xx_xxxx_time2":
      "Event date:xx/xx/xxxx\nTime: 2:00 pm\nVenue: Auditorium\nForm:",
  "msg_event_date_xx_xx_xxxx_time3":
      "Event date:xx/xx/xxxx\nTime: \nVenue: Auditorium\nForm:",

  // Frame Three Screen
  "lbl_add_club": "Add Club",
  "lbl_add_event": "Add Event",
  "lbl_edit_profile": "Edit Profile",
  "lbl_feedback": "FeedBack",
  "lbl_help": "Help",
  "lbl_home": "Home",
  "lbl_logout": "Logout",
  "lbl_planeador": "PLANEADOR",
  "lbl_privacy_policy": "Privacy Policy",
  "lbl_profile": "Profile",

  // Frame One Screen
  "lbl_add_event2": " ADD EVENT",
  "lbl_add_image": "Add image",
  "lbl_event_date": "Event Date  :",
  "lbl_event_name": "Event Name :",
  "lbl_event_time": "Event Time :",
  "lbl_organizer": "Organizer   :",
  "lbl_submit": "SUBMIT",
  "lbl_venue": "Venue         :",

  // profile page Screen
  "lbl_cancel": "   CANCEL", "lbl_edit_profile2": "EDIT PROFILE",
  "lbl_profile_image": "PROFILE IMAGE", "lbl_save": "      SAVE",

  // Frame Two Screen
  "lbl_contact_us": "Contact Us\n",
  "lbl_email_support": "Email Support\n",
  "lbl_faq": "FAQ:\n",
  "lbl_help_center": "             Help Center\n\n",
  "lbl_privacy_policy2": "Privacy Policy\n",
  "lbl_usage_data": "Usage Data: ",
  "msg_1_how_to_update":
      "1. How to update your account information\n2.How to change password\\\n\n",
  "msg_account_information": "Account Information: ",
  "msg_at_planeador_we":
      "At Planeador we take your privacy seriously. Our privacy policy outlines how we collect, use, and protect your personal information when you use our platform. By using our services, you agree to the terms of our privacy policy.\n\n",
  "msg_community_forums_engage":
      "Community Forums\nEngage with other users and our community moderators on our forums. Share your experiences, ask questions, and learn from others in the community.\n\n",
  "msg_event_information": "Event Information",
  "msg_for_non_urgent_inquiries":
      "For non-urgent inquiries or general assistance, you can contact us via email at support@example.com. Our support team strives to respond to all emails within 24 hours during regular business days.\n\n",
  "msg_help_center_welcome":
      "             Help Center\n\nWelcome to Planeador’s Help Center\n\nFAQ:\n1. How to update your account information\n2.How to change password\\\n\nPrivacy Policy\nAt Planeador we take your privacy seriously. Our privacy policy outlines how we collect, use, and protect your personal information when you use our platform. By using our services, you agree to the terms of our privacy policy.\n\nWhat Information Do We Collect?\n\nAccount Information: When you sign up for an account, we collect your name, email address, and other relevant details to create and manage your account.\n\nEvent Information: When you create events on our platform, we collect information such as event details, attendee data, and payment information .\n\nUsage Data: We collect data about how you interact with our platform, including your browsing activity, session duration, and device information.\n\n\nContact Us\nNeed assistance with our event management app? We're here to help! Our dedicated support team is available to address any questions, concerns, or technical issues you may encounter. Please feel free to reach out to us using one of the following methods:\n\nEmail Support\nFor non-urgent inquiries or general assistance, you can contact us via email at support@example.com. Our support team strives to respond to all emails within 24 hours during regular business days.\n\nCommunity Forums\nEngage with other users and our community moderators on our forums. Share your experiences, ask questions, and learn from others in the community.\n\n",
  "msg_need_assistance":
      "Need assistance with our event management app? We're here to help! Our dedicated support team is available to address any questions, concerns, or technical issues you may encounter. Please feel free to reach out to us using one of the following methods:\n\n",
  "msg_we_collect_data":
      "We collect data about how you interact with our platform, including your browsing activity, session duration, and device information.\n\n\n",
  "msg_welcome_to_planeador_s": "Welcome to Planeador’s Help Center\n\n",
  "msg_what_information": "What Information Do We Collect?\n\n",
  "msg_when_you_create":
      ": When you create events on our platform, we collect information such as event details, attendee data, and payment information .\n\n",
  "msg_when_you_sign_up":
      "When you sign up for an account, we collect your name, email address, and other relevant details to create and manage your account.\n\n",

  // Common String
  "lbl_add": "ADD",
  "lbl_add_club2": " ADD CLUB",
  "lbl_brochure": "         BROCHURE",
  "lbl_club_logo": "Club Logo",
  "lbl_club_name": "Club Name  :",
  "lbl_email": "Email",
  "lbl_incharge": "Incharge      :",
  "lbl_login": "Login",
  "lbl_or_login_with": "Or login with",
  "lbl_password": "Password",
  "lbl_president": "    President     :",
  "lbl_sign_up": "Sign Up",
  "lbl_username": "Username",
  "msg_event_date_xx_x3": "Event date:xx/xx/xxxx\nTime:\nVenue:\nForm:",
  "msg_login_with_facebook": "Login with Facebook",
  "msg_login_with_google": "Login with Google",
  "msg_motto": "Motto          :",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",

  // Validation Error String
  "err_msg_please_enter_valid_email": "Please enter valid email",
  "err_msg_please_enter_valid_password": "Please enter valid password",
  "err_msg_please_enter_valid_text": "Please enter valid text",
};
