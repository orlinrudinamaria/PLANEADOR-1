import 'package:flutter/material.dart';
import '../presentation/welcome_screen/welcome_screen.dart';
import '../presentation/login_page_screen/login_page_screen.dart';
import '../presentation/sign_up_page_screen/sign_up_page_screen.dart';
import '../presentation/home_page_screen/home_page_screen.dart';
import '../presentation/fine_arts_screen/fine_arts_screen.dart';
import '../presentation/nss_screen/nss_screen.dart';
import '../presentation/literary_club_screen/literary_club_screen.dart';
import '../presentation/eco_club_screen/eco_club_screen.dart';
import '../presentation/frame_three_screen/frame_three_screen.dart';
import '../presentation/frame_one_screen/frame_one_screen.dart';
import '../presentation/profile_page_screen/profile_page_screen.dart';
import '../presentation/frame_four_screen/frame_four_screen.dart';
import '../presentation/frame_screen/frame_screen.dart';
import '../presentation/frame_two_screen/frame_two_screen.dart';
import '../presentation/app_navigation_screen/app_navigation_screen.dart';

class AppRoutes {
  static const String welcomeScreen = '/welcome_screen';

  static const String loginPageScreen = '/login_page_screen';

  static const String signUpPageScreen = '/sign_up_page_screen';

  static const String homePageScreen = '/home_page_screen';

  static const String fineArtsScreen = '/fine_arts_screen';

  static const String nssScreen = '/nss_screen';

  static const String literaryClubScreen = '/literary_club_screen';

  static const String ecoClubScreen = '/eco_club_screen';

  static const String frameThreeScreen = '/frame_three_screen';

  static const String frameOneScreen = '/frame_one_screen';

  static const String profilePageScreen = '/profile_page_screen';

  static const String frameFourScreen = '/frame_four_screen';

  static const String frameScreen = '/frame_screen';

  static const String frameTwoScreen = '/frame_two_screen';

  static const String appNavigationScreen = '/app_navigation_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> get routes => {
        welcomeScreen: WelcomeScreen.builder,
        loginPageScreen: LoginPageScreen.builder,
        signUpPageScreen: SignUpPageScreen.builder,
        homePageScreen: HomePageScreen.builder,
        fineArtsScreen: FineArtsScreen.builder,
        nssScreen: NssScreen.builder,
        literaryClubScreen: LiteraryClubScreen.builder,
        ecoClubScreen: EcoClubScreen.builder,
        frameThreeScreen: FrameThreeScreen.builder,
        frameOneScreen: FrameOneScreen.builder,
        profilePageScreen: ProfilePageScreen.builder,
        frameFourScreen: FrameFourScreen.builder,
        frameScreen: FrameScreen.builder,
        frameTwoScreen: FrameTwoScreen.builder,
        appNavigationScreen: AppNavigationScreen.builder,
        initialRoute: WelcomeScreen.builder
      };
}
