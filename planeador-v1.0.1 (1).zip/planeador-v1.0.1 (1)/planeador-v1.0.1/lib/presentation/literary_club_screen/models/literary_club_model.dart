// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';
import '../../../core/app_export.dart';
import 'literaryclub_item_model.dart';

/// This class defines the variables used in the [literary_club_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class LiteraryClubModel extends Equatable {
  LiteraryClubModel({this.literaryclubItemList = const []}) {}

  List<LiteraryclubItemModel> literaryclubItemList;

  LiteraryClubModel copyWith(
      {List<LiteraryclubItemModel>? literaryclubItemList}) {
    return LiteraryClubModel(
      literaryclubItemList: literaryclubItemList ?? this.literaryclubItemList,
    );
  }

  @override
  List<Object?> get props => [literaryclubItemList];
}
