import 'package:planeador/widgets/app_bar/custom_app_bar.dart';
import 'package:planeador/widgets/app_bar/appbar_leading_image.dart';
import 'package:planeador/widgets/app_bar/appbar_subtitle.dart';
import 'widgets/literaryclub_item_widget.dart';
import 'models/literaryclub_item_model.dart';
import 'models/literary_club_model.dart';
import 'package:flutter/material.dart';
import 'package:planeador/core/app_export.dart';
import 'bloc/literary_club_bloc.dart';

class LiteraryClubScreen extends StatelessWidget {
  const LiteraryClubScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<LiteraryClubBloc>(
        create: (context) => LiteraryClubBloc(
            LiteraryClubState(literaryClubModelObj: LiteraryClubModel()))
          ..add(LiteraryClubInitialEvent()),
        child: LiteraryClubScreen());
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(context),
            body: SizedBox(
                width: SizeUtils.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(top: 54.v),
                    child: Container(
                        margin: EdgeInsets.only(bottom: 5.v),
                        padding: EdgeInsets.symmetric(horizontal: 26.h),
                        child: Column(children: [
                          _buildLiteraryClub(context),
                          SizedBox(height: 32.v),
                          _buildEightyNine(context)
                        ]))))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 37.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 23.h, top: 32.v, bottom: 11.v),
            onTap: () {
              onTapArrowLeft(context);
            }),
        centerTitle: true,
        title: AppbarSubtitle(text: "lbl_brochure".tr),
        styleType: Style.bgFill);
  }

  /// Section Widget
  Widget _buildLiteraryClub(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(left: 10.h),
        child: BlocSelector<LiteraryClubBloc, LiteraryClubState,
                LiteraryClubModel?>(
            selector: (state) => state.literaryClubModelObj,
            builder: (context, literaryClubModelObj) {
              return ListView.separated(
                  physics: NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  separatorBuilder: (context, index) {
                    return SizedBox(height: 25.v);
                  },
                  itemCount:
                      literaryClubModelObj?.literaryclubItemList.length ?? 0,
                  itemBuilder: (context, index) {
                    LiteraryclubItemModel model =
                        literaryClubModelObj?.literaryclubItemList[index] ??
                            LiteraryclubItemModel();
                    return LiteraryclubItemWidget(model);
                  });
            }));
  }

  /// Section Widget
  Widget _buildEightyNine(BuildContext context) {
    return Align(
        alignment: Alignment.centerRight,
        child: Padding(
            padding: EdgeInsets.only(left: 16.h),
            child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CustomImageView(
                      imagePath: ImageConstant.imgRectangle321,
                      height: 122.v,
                      width: 152.h),
                  Container(
                      width: 138.h,
                      margin: EdgeInsets.only(left: 12.h, bottom: 50.v),
                      child: Text("msg_event_date_xx_x3".tr,
                          maxLines: 4,
                          overflow: TextOverflow.ellipsis,
                          style: theme.textTheme.titleSmall))
                ])));
  }

  /// Navigates to the previous screen.
  onTapArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }
}
