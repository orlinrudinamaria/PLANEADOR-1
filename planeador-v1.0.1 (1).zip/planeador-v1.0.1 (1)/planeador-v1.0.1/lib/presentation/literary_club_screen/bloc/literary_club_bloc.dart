import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/literaryclub_item_model.dart';
import 'package:planeador/presentation/literary_club_screen/models/literary_club_model.dart';
part 'literary_club_event.dart';
part 'literary_club_state.dart';

/// A bloc that manages the state of a LiteraryClub according to the event that is dispatched to it.
class LiteraryClubBloc extends Bloc<LiteraryClubEvent, LiteraryClubState> {
  LiteraryClubBloc(LiteraryClubState initialState) : super(initialState) {
    on<LiteraryClubInitialEvent>(_onInitialize);
  }

  _onInitialize(
    LiteraryClubInitialEvent event,
    Emitter<LiteraryClubState> emit,
  ) async {
    emit(state.copyWith(
        literaryClubModelObj: state.literaryClubModelObj
            ?.copyWith(literaryclubItemList: fillLiteraryclubItemList())));
  }

  List<LiteraryclubItemModel> fillLiteraryclubItemList() {
    return [
      LiteraryclubItemModel(
          image: ImageConstant.imgRectangle262,
          eventDateXxXxXxxx: "Event date:xx/xx/xxxx\nTime:\nVenue:\nForm:"),
      LiteraryclubItemModel(
          image: ImageConstant.imgRectangle271,
          eventDateXxXxXxxx: "Event date:xx/xx/xxxx\nTime:\nVenue:\nForm:"),
      LiteraryclubItemModel(
          image: ImageConstant.imgRectangle291,
          eventDateXxXxXxxx: "Event date:xx/xx/xxxx\nTime:\nVenue:\nForm:"),
      LiteraryclubItemModel(
          image: ImageConstant.imgRectangle301,
          eventDateXxXxXxxx: "Event date:xx/xx/xxxx\nTime:\nVenue:\nForm:"),
      LiteraryclubItemModel(
          image: ImageConstant.imgRectangle311,
          eventDateXxXxXxxx: "Event date:xx/xx/xxxx\nTime:\nVenue:\nForm:")
    ];
  }
}
