// ignore_for_file: must_be_immutable

part of 'literary_club_bloc.dart';

/// Represents the state of LiteraryClub in the application.
class LiteraryClubState extends Equatable {
  LiteraryClubState({this.literaryClubModelObj});

  LiteraryClubModel? literaryClubModelObj;

  @override
  List<Object?> get props => [
        literaryClubModelObj,
      ];

  LiteraryClubState copyWith({LiteraryClubModel? literaryClubModelObj}) {
    return LiteraryClubState(
      literaryClubModelObj: literaryClubModelObj ?? this.literaryClubModelObj,
    );
  }
}
