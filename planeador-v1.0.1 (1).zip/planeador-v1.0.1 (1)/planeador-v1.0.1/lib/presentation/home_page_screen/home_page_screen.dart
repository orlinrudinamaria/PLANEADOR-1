import 'package:planeador/widgets/app_bar/custom_app_bar.dart';
import 'package:planeador/widgets/app_bar/appbar_leading_image.dart';
import 'package:planeador/widgets/app_bar/appbar_subtitle.dart';
import 'package:staggered_grid_view_flutter/widgets/staggered_grid_view.dart';
import 'package:staggered_grid_view_flutter/widgets/staggered_tile.dart';
import 'widgets/homepage_item_widget.dart';
import 'models/homepage_item_model.dart';
import 'models/home_page_model.dart';
import 'package:flutter/material.dart';
import 'package:planeador/core/app_export.dart';
import 'bloc/home_page_bloc.dart';

class HomePageScreen extends StatelessWidget {
  const HomePageScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<HomePageBloc>(
        create: (context) =>
            HomePageBloc(HomePageState(homePageModelObj: HomePageModel()))
              ..add(HomePageInitialEvent()),
        child: HomePageScreen());
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(context),
            body: SizedBox(
                width: SizeUtils.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(top: 23.v),
                    child: Container(
                        margin: EdgeInsets.only(bottom: 5.v),
                        padding: EdgeInsets.symmetric(horizontal: 14.h),
                        child: Column(children: [
                          _buildWidget(context),
                          _buildHomePage(context),
                          SizedBox(height: 23.v),
                          CustomImageView(
                              imagePath: ImageConstant.imgRectangle26,
                              height: 154.v,
                              width: 163.h,
                              radius: BorderRadius.circular(20.h),
                              alignment: Alignment.centerLeft,
                              margin: EdgeInsets.only(left: 10.h))
                        ]))))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 65.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgMenu,
            margin: EdgeInsets.only(left: 18.h, top: 18.v, bottom: 6.v),
            onTap: () {
              onTapMenu(context);
            }),
        centerTitle: true,
        title: AppbarSubtitle(text: "lbl_clubs".tr),
        styleType: Style.bgFill);
  }

  /// Section Widget
  Widget _buildWidget(BuildContext context) {
    return SizedBox(
        height: 522.v,
        width: 326.h,
        child: Stack(alignment: Alignment.topCenter, children: [
          CustomImageView(
              imagePath: ImageConstant.imgRectangle13,
              height: 174.v,
              width: 168.h,
              radius: BorderRadius.circular(20.h),
              alignment: Alignment.bottomLeft),
          Align(
              alignment: Alignment.topCenter,
              child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Padding(
                        padding: EdgeInsets.only(right: 7.h),
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Expanded(
                                  child: CustomImageView(
                                      imagePath: ImageConstant.imgRectangle12,
                                      height: 153.v,
                                      width: 145.h,
                                      radius: BorderRadius.circular(20.h),
                                      margin: EdgeInsets.only(right: 14.h),
                                      onTap: () {
                                        onTapImgImage(context);
                                      })),
                              Expanded(
                                  child: CustomImageView(
                                      imagePath: ImageConstant.imgRectangle15,
                                      height: 153.v,
                                      width: 145.h,
                                      margin: EdgeInsets.only(left: 14.h),
                                      onTap: () {
                                        onTapImgImage1(context);
                                      }))
                            ])),
                    SizedBox(height: 23.v),
                    Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                              child: CustomImageView(
                                  imagePath: ImageConstant.imgRectangle14,
                                  height: 153.v,
                                  width: 145.h,
                                  radius: BorderRadius.circular(20.h),
                                  margin: EdgeInsets.only(
                                      right: 18.h, bottom: 19.v),
                                  onTap: () {
                                    onTapImgImage2(context);
                                  })),
                          Expanded(
                              child: CustomImageView(
                                  imagePath: ImageConstant.imgRectangle16,
                                  height: 153.v,
                                  width: 145.h,
                                  radius: BorderRadius.circular(20.h),
                                  margin:
                                      EdgeInsets.only(left: 18.h, top: 19.v),
                                  onTap: () {
                                    onTapImgImage3(context);
                                  }))
                        ]),
                    SizedBox(height: 10.v),
                    CustomImageView(
                        imagePath: ImageConstant.imgRectangle17,
                        height: 139.adaptSize,
                        width: 139.adaptSize,
                        radius: BorderRadius.circular(35.h),
                        margin: EdgeInsets.only(right: 13.h))
                  ]))
        ]));
  }

  /// Section Widget
  Widget _buildHomePage(BuildContext context) {
    return BlocSelector<HomePageBloc, HomePageState, HomePageModel?>(
        selector: (state) => state.homePageModelObj,
        builder: (context, homePageModelObj) {
          return StaggeredGridView.countBuilder(
              shrinkWrap: true,
              primary: false,
              crossAxisCount: 4,
              crossAxisSpacing: 11.h,
              mainAxisSpacing: 11.h,
              staggeredTileBuilder: (index) {
                return StaggeredTile.fit(2);
              },
              itemCount: homePageModelObj?.homepageItemList.length ?? 0,
              itemBuilder: (context, index) {
                HomepageItemModel model =
                    homePageModelObj?.homepageItemList[index] ??
                        HomepageItemModel();
                return HomepageItemWidget(model);
              });
        });
  }

  /// Navigates to the frameThreeScreen when the action is triggered.
  onTapMenu(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.frameThreeScreen,
    );
  }

  /// Navigates to the fineArtsScreen when the action is triggered.
  onTapImgImage(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.fineArtsScreen,
    );
  }

  /// Navigates to the nssScreen when the action is triggered.
  onTapImgImage1(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.nssScreen,
    );
  }

  /// Navigates to the literaryClubScreen when the action is triggered.
  onTapImgImage2(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.literaryClubScreen,
    );
  }

  /// Navigates to the ecoClubScreen when the action is triggered.
  onTapImgImage3(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.ecoClubScreen,
    );
  }
}
