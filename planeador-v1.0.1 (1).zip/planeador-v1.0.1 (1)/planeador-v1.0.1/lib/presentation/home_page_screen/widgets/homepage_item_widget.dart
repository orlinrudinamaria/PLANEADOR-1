import '../models/homepage_item_model.dart';
import 'package:flutter/material.dart';
import 'package:planeador/core/app_export.dart';

// ignore: must_be_immutable
class HomepageItemWidget extends StatelessWidget {
  HomepageItemWidget(
    this.homepageItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  HomepageItemModel homepageItemModelObj;

  @override
  Widget build(BuildContext context) {
    return CustomImageView(
      imagePath: homepageItemModelObj?.rectangle,
      height: 149.v,
      width: 162.h,
      radius: BorderRadius.circular(
        20.h,
      ),
    );
  }
}
