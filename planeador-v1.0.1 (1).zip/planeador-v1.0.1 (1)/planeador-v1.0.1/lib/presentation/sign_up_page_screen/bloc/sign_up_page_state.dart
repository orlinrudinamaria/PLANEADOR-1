// ignore_for_file: must_be_immutable

part of 'sign_up_page_bloc.dart';

/// Represents the state of SignUpPage in the application.
class SignUpPageState extends Equatable {
  SignUpPageState({
    this.userNameController,
    this.emailController,
    this.passwordController,
    this.isShowPassword = true,
    this.signUpPageModelObj,
  });

  TextEditingController? userNameController;

  TextEditingController? emailController;

  TextEditingController? passwordController;

  SignUpPageModel? signUpPageModelObj;

  bool isShowPassword;

  @override
  List<Object?> get props => [
        userNameController,
        emailController,
        passwordController,
        isShowPassword,
        signUpPageModelObj,
      ];

  SignUpPageState copyWith({
    TextEditingController? userNameController,
    TextEditingController? emailController,
    TextEditingController? passwordController,
    bool? isShowPassword,
    SignUpPageModel? signUpPageModelObj,
  }) {
    return SignUpPageState(
      userNameController: userNameController ?? this.userNameController,
      emailController: emailController ?? this.emailController,
      passwordController: passwordController ?? this.passwordController,
      isShowPassword: isShowPassword ?? this.isShowPassword,
      signUpPageModelObj: signUpPageModelObj ?? this.signUpPageModelObj,
    );
  }
}
