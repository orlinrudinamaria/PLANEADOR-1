import 'package:flutter/material.dart';

import '../../core/app_export.dart';
import '../../core/utils/validation_functions.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_text_form_field.dart';
import 'bloc/sign_up_page_bloc.dart';
import 'models/sign_up_page_model.dart';

class SignUpPageScreen extends StatelessWidget {
  SignUpPageScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<SignUpPageBloc>(
        create: (context) => SignUpPageBloc(
            SignUpPageState(signUpPageModelObj: SignUpPageModel()))
          ..add(SignUpPageInitialEvent()),
        child: SignUpPageScreen());
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SizedBox(
                width: SizeUtils.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).viewInsets.bottom),
                    child: Form(
                        key: _formKey,
                        child: Container(
                            width: double.maxFinite,
                            padding: EdgeInsets.symmetric(
                                horizontal: 25.h, vertical: 51.v),
                            child: Column(children: [
                              Align(
                                  alignment: Alignment.centerLeft,
                                  child: Padding(
                                      padding: EdgeInsets.only(right: 66.h),
                                      child: Row(
                                          crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                          children: [
                                            CustomImageView(
                                                imagePath:
                                                ImageConstant.imgArrowLeft,
                                                height: 30.v,
                                                width: 27.h,
                                                margin: EdgeInsets.only(
                                                    top: 1.v, bottom: 8.v),
                                                onTap: () {
                                                  onTapImgArrowLeft(context);
                                                }),
                                            Padding(
                                                padding:
                                                EdgeInsets.only(left: 39.h),
                                                child: Text("lbl_signup_now".tr,
                                                    style: theme.textTheme
                                                        .headlineLarge))
                                          ]))),
                              SizedBox(height: 42.v),
                              _buildUserName(context),
                              SizedBox(height: 36.v),
                              _buildEmail(context),
                              SizedBox(height: 34.v),
                              _buildPassword(context),
                              SizedBox(height: 50.v),
                              Text("lbl_or_login_with".tr,
                                  style: CustomTextStyles.titleSmallGray100),
                              SizedBox(height: 32.v),
                              _buildLoginWithFacebook(context),
                              SizedBox(height: 21.v),
                              _buildLoginWithGoogle(context),
                              SizedBox(height: 49.v),
                              _buildSignUp(context),
                              SizedBox(height: 5.v)
                            ])))))));
  }

  /// Section Widget
  Widget _buildUserName(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 28.h),
        child: BlocSelector<SignUpPageBloc, SignUpPageState,
            TextEditingController?>(
            selector: (state) => state.userNameController,
            builder: (context, userNameController) {
              return CustomTextFormField(
                  controller: userNameController,
                  hintText: "lbl_username".tr,
                  validator: (value) {
                    if (!isText(value)) {
                      return "err_msg_please_enter_valid_text".tr;
                    }
                    return null;
                  },
                  contentPadding: EdgeInsets.symmetric(horizontal: 5.h));
            }));
  }

  /// Section Widget
  Widget _buildEmail(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 28.h),
        child: BlocSelector<SignUpPageBloc, SignUpPageState,
            TextEditingController?>(
            selector: (state) => state.emailController,
            builder: (context, emailController) {
              return CustomTextFormField(
                  controller: emailController,
                  hintText: "lbl_email".tr,
                  textInputType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null ||
                        (!isValidEmail(value, isRequired: true))) {
                      return "err_msg_please_enter_valid_email".tr;
                    }
                    return null;
                  },
                  contentPadding: EdgeInsets.symmetric(horizontal: 5.h));
            }));
  }

  /// Section Widget
  Widget _buildPassword(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(left: 27.h, right: 28.h),
        child: BlocBuilder<SignUpPageBloc, SignUpPageState>(
            builder: (context, state) {
              return CustomTextFormField(
                  controller: state.passwordController,
                  hintText: "lbl_password".tr,
                  textInputAction: TextInputAction.done,
                  textInputType: TextInputType.visiblePassword,
                  suffix: InkWell(
                      onTap: () {
                        context.read<SignUpPageBloc>().add(
                            ChangePasswordVisibilityEvent(
                                value: !state.isShowPassword));
                      },
                      child: Container(
                          margin: EdgeInsets.only(left: 30.h, right: 3.h),
                          child: CustomImageView(
                              imagePath: ImageConstant.imgEye,
                              height: 19.v,
                              width: 22.h))),
                  suffixConstraints: BoxConstraints(maxHeight: 32.v),
                  validator: (value) {
                    if (value == null ||
                        (!isValidPassword(value, isRequired: true))) {
                      return "err_msg_please_enter_valid_password".tr;
                    }
                    return null;
                  },
                  obscureText: state.isShowPassword);
            }));
  }

  /// Section Widget
  Widget _buildLoginWithFacebook(BuildContext context) {
    return CustomElevatedButton(
        text: "msg_login_with_facebook".tr,
        margin: EdgeInsets.only(left: 32.h, right: 28.h),
        leftIcon: Container(
            margin: EdgeInsets.only(right: 18.h),
            child: CustomImageView(
                imagePath: ImageConstant.imgLogosfacebook,
                height: 16.adaptSize,
                width: 16.adaptSize)),
        buttonStyle: CustomButtonStyles.fillPrimaryTL10,
        buttonTextStyle: CustomTextStyles.titleSmallGray100,
        onPressed: () {
          onTapLoginWithFacebook(context);
        });
  }

  /// Section Widget
  Widget _buildLoginWithGoogle(BuildContext context) {
    return CustomElevatedButton(
        text: "msg_login_with_google".tr,
        margin: EdgeInsets.only(left: 33.h, right: 28.h),
        leftIcon: Container(
            margin: EdgeInsets.only(right: 18.h),
            child: CustomImageView(
                imagePath: ImageConstant.imgFlatcoloriconsgoogle,
                height: 16.adaptSize,
                width: 16.adaptSize)),
        buttonStyle: CustomButtonStyles.fillPrimaryTL101,
        buttonTextStyle: CustomTextStyles.titleSmallGray100,
        onPressed: () {
          onTapLoginWithGoogle(context);
        });
  }

  /// Section Widget
  Widget _buildSignUp(BuildContext context) {
    return CustomElevatedButton(
        text: "lbl_sign_up".tr,
        margin: EdgeInsets.only(left: 33.h, right: 28.h),
        onPressed: () {
          onTapSignUp(context);
        });
  }

  /// Navigates to the previous screen.
  onTapImgArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }

  /// Navigates to the homePageScreen when the action is triggered.
  onTapSignUp(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.homePageScreen,
    );
  }

  /// Handles the Facebook login action.
  void onTapLoginWithFacebook(BuildContext context) {
    // Implement your logic for Facebook login here
    // For example, you can navigate to another page
    // Navigator.push(
    //   context,
    //   MaterialPageRoute(builder: (context) => FacebookLoginPage()),
    // );
    print('Login with Facebook tapped');
  }
}

void onTapLoginWithGoogle(BuildContext context) {
  print('Login with google tapped');


}
