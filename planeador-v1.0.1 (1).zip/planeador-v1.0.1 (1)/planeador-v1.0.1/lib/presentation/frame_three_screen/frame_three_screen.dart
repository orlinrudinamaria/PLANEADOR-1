import 'models/frame_three_model.dart';
import 'package:flutter/material.dart';
import 'package:planeador/core/app_export.dart';
import 'bloc/frame_three_bloc.dart';

class FrameThreeScreen extends StatelessWidget {
  const FrameThreeScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<FrameThreeBloc>(
        create: (context) => FrameThreeBloc(
            FrameThreeState(frameThreeModelObj: FrameThreeModel()))
          ..add(FrameThreeInitialEvent()),
        child: FrameThreeScreen());
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<FrameThreeBloc, FrameThreeState>(
        builder: (context, state) {
      return SafeArea(
          child: Scaffold(
              body: SizedBox(
                  width: double.maxFinite,
                  child: Column(children: [
                    SizedBox(height: 32.v),
                    Expanded(
                        child: SingleChildScrollView(
                            child: Container(
                                margin: EdgeInsets.only(bottom: 69.v),
                                padding: EdgeInsets.symmetric(horizontal: 16.h),
                                child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                          padding: EdgeInsets.only(right: 62.h),
                                          child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgObject12,
                                                    height: 81.v,
                                                    width: 92.h),
                                                Padding(
                                                    padding: EdgeInsets.only(
                                                        left: 11.h,
                                                        top: 17.v,
                                                        bottom: 33.v),
                                                    child: Text(
                                                        "lbl_planeador".tr,
                                                        style: theme.textTheme
                                                            .headlineSmall))
                                              ])),
                                      SizedBox(height: 36.v),
                                      Padding(
                                          padding: EdgeInsets.only(left: 12.h),
                                          child: Row(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                CustomImageView(
                                                    imagePath: ImageConstant
                                                        .imgThumbsUp,
                                                    height: 19.v,
                                                    width: 18.h,
                                                    margin: EdgeInsets.only(
                                                        bottom: 5.v)),
                                                GestureDetector(
                                                    onTap: () {
                                                      onTapTxtHome(context);
                                                    },
                                                    child: Padding(
                                                        padding:
                                                            EdgeInsets.only(
                                                                left: 15.h),
                                                        child: Text(
                                                            "lbl_home".tr,
                                                            style: theme
                                                                .textTheme
                                                                .titleLarge)))
                                              ])),
                                      SizedBox(height: 30.v),
                                      Padding(
                                          padding: EdgeInsets.only(left: 13.h),
                                          child: Row(children: [
                                            CustomImageView(
                                                imagePath:
                                                    ImageConstant.imgLock,
                                                height: 20.v,
                                                width: 16.h,
                                                margin: EdgeInsets.only(
                                                    bottom: 4.v)),
                                            Padding(
                                                padding:
                                                    EdgeInsets.only(left: 16.h),
                                                child: Text("lbl_profile".tr,
                                                    style: theme
                                                        .textTheme.titleLarge))
                                          ])),
                                      SizedBox(height: 31.v),
                                      Padding(
                                          padding: EdgeInsets.only(left: 8.h),
                                          child: Row(children: [
                                            Container(
                                                height: 22.adaptSize,
                                                width: 22.adaptSize,
                                                margin: EdgeInsets.only(
                                                    bottom: 2.v),
                                                child: Stack(
                                                    alignment:
                                                        Alignment.bottomCenter,
                                                    children: [
                                                      CustomImageView(
                                                          imagePath:
                                                              ImageConstant
                                                                  .imgCalendar,
                                                          height: 22.adaptSize,
                                                          width: 22.adaptSize,
                                                          alignment:
                                                              Alignment.center),
                                                      CustomImageView(
                                                          imagePath:
                                                              ImageConstant
                                                                  .imgClose,
                                                          height: 6.adaptSize,
                                                          width: 6.adaptSize,
                                                          alignment: Alignment
                                                              .bottomCenter,
                                                          margin:
                                                              EdgeInsets.only(
                                                                  bottom: 4.v))
                                                    ])),
                                            GestureDetector(
                                                onTap: () {
                                                  onTapTxtAddEvent(context);
                                                },
                                                child: Padding(
                                                    padding: EdgeInsets.only(
                                                        left: 15.h),
                                                    child: Text(
                                                        "lbl_add_event".tr,
                                                        style: theme.textTheme
                                                            .titleLarge)))
                                          ])),
                                      SizedBox(height: 25.v),
                                      GestureDetector(
                                          onTap: () {
                                            onTapTxtAddClub(context);
                                          },
                                          child: Padding(
                                              padding:
                                                  EdgeInsets.only(left: 45.h),
                                              child: Text("lbl_add_club".tr,
                                                  style: theme
                                                      .textTheme.titleLarge))),
                                      SizedBox(height: 24.v),
                                      Padding(
                                          padding: EdgeInsets.only(left: 8.h),
                                          child: Row(children: [
                                            SizedBox(
                                                height: 28.v,
                                                width: 22.h,
                                                child: Stack(
                                                    alignment:
                                                        Alignment.bottomCenter,
                                                    children: [
                                                      CustomImageView(
                                                          imagePath:
                                                              ImageConstant
                                                                  .imgTelevision,
                                                          height: 15.v,
                                                          width: 12.h,
                                                          alignment: Alignment
                                                              .topCenter),
                                                      CustomImageView(
                                                          imagePath:
                                                              ImageConstant
                                                                  .imgAirplane,
                                                          height: 14.v,
                                                          width: 22.h,
                                                          alignment: Alignment
                                                              .bottomCenter)
                                                    ])),
                                            Padding(
                                                padding: EdgeInsets.only(
                                                    left: 13.h, top: 3.v),
                                                child: Text(
                                                    "lbl_privacy_policy".tr,
                                                    style: theme
                                                        .textTheme.titleLarge))
                                          ])),
                                      SizedBox(height: 24.v),
                                      Padding(
                                          padding: EdgeInsets.only(left: 8.h),
                                          child: Row(children: [
                                            CustomImageView(
                                                imagePath:
                                                    ImageConstant.imgProfile,
                                                height: 21.v,
                                                width: 27.h,
                                                margin: EdgeInsets.only(
                                                    bottom: 3.v),
                                                onTap: () {
                                                  onTapImgProfile(context);
                                                }),
                                            GestureDetector(
                                                onTap: () {
                                                  onTapTxtHelp(context);
                                                },
                                                child: Padding(
                                                    padding: EdgeInsets.only(
                                                        left: 11.h),
                                                    child: Text("lbl_help".tr,
                                                        style: theme.textTheme
                                                            .titleLarge)))
                                          ])),
                                      SizedBox(height: 16.v),
                                      Padding(
                                          padding: EdgeInsets.only(left: 4.h),
                                          child: Row(children: [
                                            CustomImageView(
                                                imagePath:
                                                    ImageConstant.imgVector,
                                                height: 32.v,
                                                width: 33.h),
                                            Padding(
                                                padding: EdgeInsets.only(
                                                    left: 7.h, top: 6.v),
                                                child: Text("lbl_feedback".tr,
                                                    style: theme
                                                        .textTheme.titleLarge))
                                          ])),
                                      SizedBox(height: 21.v),
                                      Padding(
                                          padding: EdgeInsets.only(left: 14.h),
                                          child: Row(children: [
                                            CustomImageView(
                                                imagePath:
                                                    ImageConstant.imgForward,
                                                height: 20.v,
                                                width: 16.h,
                                                margin: EdgeInsets.symmetric(
                                                    vertical: 2.v)),
                                            GestureDetector(
                                                onTap: () {
                                                  onTapTxtLogin(context);
                                                },
                                                child: Padding(
                                                    padding: EdgeInsets.only(
                                                        left: 14.h),
                                                    child: Text("lbl_login".tr,
                                                        style: theme.textTheme
                                                            .titleLarge)))
                                          ])),
                                      SizedBox(height: 18.v),
                                      Padding(
                                          padding: EdgeInsets.only(left: 5.h),
                                          child: Row(children: [
                                            CustomImageView(
                                                imagePath: ImageConstant
                                                    .imgLockOnerrorcontainer,
                                                height: 25.v,
                                                width: 30.h,
                                                onTap: () {
                                                  onTapImgLock(context);
                                                }),
                                            Padding(
                                                padding:
                                                    EdgeInsets.only(left: 9.h),
                                                child: Text(
                                                    "lbl_edit_profile".tr,
                                                    style: theme
                                                        .textTheme.titleLarge))
                                          ])),
                                      SizedBox(height: 160.v),
                                      Padding(
                                          padding: EdgeInsets.only(left: 16.h),
                                          child: Row(children: [
                                            CustomImageView(
                                                imagePath:
                                                    ImageConstant.imgArrowDown,
                                                height: 20.v,
                                                width: 16.h,
                                                margin: EdgeInsets.only(
                                                    bottom: 4.v),
                                                onTap: () {
                                                  onTapImgArrowDown(context);
                                                }),
                                            GestureDetector(
                                                onTap: () {
                                                  onTapTxtLogout(context);
                                                },
                                                child: Padding(
                                                    padding: EdgeInsets.only(
                                                        left: 14.h),
                                                    child: Text("lbl_logout".tr,
                                                        style: theme.textTheme
                                                            .titleLarge)))
                                          ]))
                                    ]))))
                  ]))));
    });
  }

  /// Navigates to the homePageScreen when the action is triggered.
  onTapTxtHome(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.homePageScreen,
    );
  }

  /// Navigates to the frameOneScreen when the action is triggered.
  onTapTxtAddEvent(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.frameOneScreen,
    );
  }

  /// Navigates to the frameFourScreen when the action is triggered.
  onTapTxtAddClub(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.frameFourScreen,
    );
  }

  /// Navigates to the frameTwoScreen when the action is triggered.
  onTapImgProfile(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.frameTwoScreen,
    );
  }

  /// Navigates to the frameTwoScreen when the action is triggered.
  onTapTxtHelp(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.frameTwoScreen,
    );
  }

  /// Navigates to the loginPageScreen when the action is triggered.
  onTapTxtLogin(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.loginPageScreen,
    );
  }

  /// Navigates to the profilePageScreen when the action is triggered.
  onTapImgLock(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.profilePageScreen,
    );
  }

  /// Navigates to the welcomeScreen when the action is triggered.
  onTapImgArrowDown(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.welcomeScreen,
    );
  }

  /// Navigates to the welcomeScreen when the action is triggered.
  onTapTxtLogout(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.welcomeScreen,
    );
  }
}
