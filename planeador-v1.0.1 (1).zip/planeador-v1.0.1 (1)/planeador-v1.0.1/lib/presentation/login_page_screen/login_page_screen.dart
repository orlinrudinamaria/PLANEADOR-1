import 'package:planeador/core/utils/validation_functions.dart';
import 'package:planeador/presentation/sign_up_page_screen/sign_up_page_screen.dart';
import 'package:planeador/widgets/custom_text_form_field.dart';
import 'package:planeador/widgets/custom_elevated_button.dart';
import 'models/login_page_model.dart';
import 'package:flutter/material.dart';
import 'package:planeador/core/app_export.dart';
import 'bloc/login_page_bloc.dart';

// ignore_for_file: must_be_immutable
class LoginPageScreen extends StatelessWidget {
  LoginPageScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<LoginPageBloc>(
        create: (context) =>
            LoginPageBloc(LoginPageState(loginPageModelObj: LoginPageModel()))
              ..add(LoginPageInitialEvent()),
        child: LoginPageScreen());
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            body: SizedBox(
                width: SizeUtils.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).viewInsets.bottom),
                    child: Form(
                        key: _formKey,
                        child: Container(
                            width: double.maxFinite,
                            padding: EdgeInsets.symmetric(
                                horizontal: 26.h, vertical: 49.v),
                            child: Column(children: [
                              Align(
                                  alignment: Alignment.centerLeft,
                                  child: Padding(
                                      padding: EdgeInsets.only(right: 75.h),
                                      child: Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            CustomImageView(
                                                imagePath:
                                                    ImageConstant.imgArrowLeft,
                                                height: 30.v,
                                                width: 27.h,
                                                margin: EdgeInsets.only(
                                                    bottom: 13.v),
                                                onTap: () {
                                                  onTapImgArrowLeft(context);
                                                }),
                                            Padding(
                                                padding: EdgeInsets.only(
                                                    left: 48.h, top: 3.v),
                                                child: Text("lbl_login_now".tr,
                                                    style: theme.textTheme
                                                        .headlineLarge))
                                          ]))),
                              SizedBox(height: 40.v),
                              _buildEmail(context),
                              SizedBox(height: 38.v),
                              _buildPassword(context),
                              SizedBox(height: 39.v),
                              _buildLogin(context),
                              SizedBox(height: 17.v),
                              Text("lbl_or_login_with".tr,
                                  style: theme.textTheme.titleSmall),
                              SizedBox(height: 19.v),
                              _buildLoginWithFacebook(context),
                              SizedBox(height: 21.v),
                              _buildLoginWithGoogle(context),
                              SizedBox(height: 31.v),
                              Text("msg_don_t_have_an_account".tr,
                                  style: CustomTextStyles.titleSmallBlack900),
                              SizedBox(height: 28.v),
                              _buildSignUp(context),
                              SizedBox(height: 5.v)
                            ])))))));
  }

  /// Section Widget
  Widget _buildEmail(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(left: 28.h, right: 26.h),
        child:
            BlocSelector<LoginPageBloc, LoginPageState, TextEditingController?>(
                selector: (state) => state.emailController,
                builder: (context, emailController) {
                  return CustomTextFormField(
                      controller: emailController,
                      hintText: "lbl_email".tr,
                      textInputType: TextInputType.emailAddress,
                      validator: (value) {
                        if (value == null ||
                            (!isValidEmail(value, isRequired: true))) {
                          return "err_msg_please_enter_valid_email".tr;
                        }
                        return null;
                      },
                      contentPadding: EdgeInsets.symmetric(horizontal: 5.h));
                }));
  }

  /// Section Widget
  Widget _buildPassword(BuildContext context) {
    return Padding(
        padding: EdgeInsets.symmetric(horizontal: 27.h),
        child: BlocBuilder<LoginPageBloc, LoginPageState>(
            builder: (context, state) {
          return CustomTextFormField(
              controller: state.passwordController,
              hintText: "lbl_password".tr,
              textInputAction: TextInputAction.done,
              textInputType: TextInputType.visiblePassword,
              suffix: InkWell(
                  onTap: () {
                    context.read<LoginPageBloc>().add(
                        ChangePasswordVisibilityEvent(
                            value: !state.isShowPassword));
                  },
                  child: Container(
                      margin:
                          EdgeInsets.only(left: 30.h, right: 3.h, bottom: 4.v),
                      child: CustomImageView(
                          imagePath: ImageConstant.imgMdihide,
                          height: 24.adaptSize,
                          width: 24.adaptSize))),
              suffixConstraints: BoxConstraints(maxHeight: 28.v),
              validator: (value) {
                if (value == null ||
                    (!isValidPassword(value, isRequired: true))) {
                  return "err_msg_please_enter_valid_password".tr;
                }
                return null;
              },
              obscureText: state.isShowPassword);
        }));
  }

  /// Section Widget
  Widget _buildLogin(BuildContext context) {
    return CustomElevatedButton(
        text: "lbl_login".tr,
        margin: EdgeInsets.only(left: 29.h, right: 30.h),
        onPressed: () {
          onTapLogin(context);
        });
  }

  /// Section Widget
  Widget _buildLoginWithFacebook(BuildContext context) {
    return CustomElevatedButton(
        text: "msg_login_with_facebook".tr,
        margin: EdgeInsets.only(left: 28.h, right: 30.h),
        leftIcon: Container(
            margin: EdgeInsets.only(right: 18.h),
            child: CustomImageView(
                imagePath: ImageConstant.imgLogosfacebook,
                height: 16.adaptSize,
                width: 16.adaptSize)),
        buttonStyle: CustomButtonStyles.fillPrimaryTL10,
        buttonTextStyle: CustomTextStyles.titleSmallGray100,
        onPressed: () {
           onTapLoginWithFacebook(context);
        });
  }

  /// Section Widget
  Widget _buildLoginWithGoogle(BuildContext context) {
    return CustomElevatedButton(
        text: "msg_login_with_google".tr,
        margin: EdgeInsets.only(left: 29.h, right: 30.h),
        leftIcon: Container(
            margin: EdgeInsets.only(right: 18.h),
            child: CustomImageView(
                imagePath: ImageConstant.imgFlatcoloriconsgoogle,
                height: 16.adaptSize,
                width: 16.adaptSize)),
        buttonStyle: CustomButtonStyles.fillOnPrimaryContainer,
        buttonTextStyle: CustomTextStyles.titleSmallGray100,
        onPressed: () {
          onTapLoginWithGoogle(context);
        });
  }

  /// Section Widget
  Widget _buildSignUp(BuildContext context) {
    return CustomElevatedButton(
        text: "lbl_sign_up".tr,
        margin: EdgeInsets.only(left: 29.h, right: 30.h),
        onPressed: () {
          onTapSignUp(context);
        });
  }

  /// Navigates to the previous screen.
  onTapImgArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }

  /// Navigates to the homePageScreen when the action is triggered.
  onTapLogin(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.homePageScreen,
    );
  }

  /// Navigates to the signUpPageScreen when the action is triggered.
  onTapSignUp(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.signUpPageScreen,
    );
  }

  void onTapLoginWithFacebook(BuildContext context) {}
}
