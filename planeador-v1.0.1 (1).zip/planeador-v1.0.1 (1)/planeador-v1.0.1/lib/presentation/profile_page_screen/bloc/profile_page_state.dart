// ignore_for_file: must_be_immutable

part of 'profile_page_bloc.dart';

/// Represents the state of ProfilePage in the application.
class ProfilePageState extends Equatable {
  ProfilePageState({
    this.emailController,
    this.passwordController,
    this.profilePageModelObj,
  });

  TextEditingController? emailController;

  TextEditingController? passwordController;

  ProfilePageModel? profilePageModelObj;

  @override
  List<Object?> get props => [
        emailController,
        passwordController,
        profilePageModelObj,
      ];

  ProfilePageState copyWith({
    TextEditingController? emailController,
    TextEditingController? passwordController,
    ProfilePageModel? profilePageModelObj,
  }) {
    return ProfilePageState(
      emailController: emailController ?? this.emailController,
      passwordController: passwordController ?? this.passwordController,
      profilePageModelObj: profilePageModelObj ?? this.profilePageModelObj,
    );
  }
}
