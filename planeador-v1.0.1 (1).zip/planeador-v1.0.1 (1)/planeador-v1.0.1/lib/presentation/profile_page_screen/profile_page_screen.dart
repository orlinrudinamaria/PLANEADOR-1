import 'package:planeador/widgets/app_bar/custom_app_bar.dart';
import 'package:planeador/widgets/app_bar/appbar_leading_image.dart';
import 'package:planeador/widgets/app_bar/appbar_title.dart';
import 'package:planeador/core/utils/validation_functions.dart';
import 'package:planeador/widgets/custom_text_form_field.dart';
import 'package:planeador/widgets/custom_elevated_button.dart';
import 'models/profile_page_model.dart';
import 'package:flutter/material.dart';
import 'package:planeador/core/app_export.dart';
import 'bloc/profile_page_bloc.dart';

// ignore_for_file: must_be_immutable
class ProfilePageScreen extends StatelessWidget {
  ProfilePageScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<ProfilePageBloc>(
        create: (context) => ProfilePageBloc(
            ProfilePageState(profilePageModelObj: ProfilePageModel()))
          ..add(ProfilePageInitialEvent()),
        child: ProfilePageScreen());
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            appBar: _buildAppBar(context),
            body: SizedBox(
                width: SizeUtils.width,
                child: SingleChildScrollView(
                    padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).viewInsets.bottom),
                    child: Form(
                        key: _formKey,
                        child: Container(
                            width: double.maxFinite,
                            padding: EdgeInsets.symmetric(
                                horizontal: 37.h, vertical: 25.v),
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                      height: 93.v,
                                      width: 98.h,
                                      margin: EdgeInsets.only(left: 88.h),
                                      padding: EdgeInsets.all(8.h),
                                      decoration: AppDecoration.fillGray
                                          .copyWith(
                                              borderRadius: BorderRadiusStyle
                                                  .roundedBorder46),
                                      child: CustomImageView(
                                          imagePath: ImageConstant.imgAddImage,
                                          height: 76.v,
                                          width: 81.h,
                                          radius: BorderRadius.circular(32.h),
                                          alignment: Alignment.center)),
                                  SizedBox(height: 8.v),
                                  Align(
                                      alignment: Alignment.center,
                                      child: Text("lbl_profile_image".tr,
                                          style: theme.textTheme.labelLarge)),
                                  SizedBox(height: 25.v),
                                  Padding(
                                      padding: EdgeInsets.only(left: 108.h),
                                      child: Text("lbl_username".tr,
                                          style: theme.textTheme.bodyMedium)),
                                  SizedBox(height: 23.v),
                                  Divider(
                                      color: appTheme.gray100,
                                      indent: 10.h,
                                      endIndent: 22.h),
                                  SizedBox(height: 23.v),
                                  _buildEmail(context),
                                  SizedBox(height: 23.v),
                                  _buildPassword(context),
                                  SizedBox(height: 91.v),
                                  Align(
                                      alignment: Alignment.centerRight,
                                      child: Padding(
                                          padding: EdgeInsets.only(left: 15.h),
                                          child: Row(
                                              mainAxisAlignment:
                                                  MainAxisAlignment
                                                      .spaceBetween,
                                              children: [
                                                _buildCANCEL(context),
                                                _buildSAVE(context)
                                              ]))),
                                  SizedBox(height: 5.v)
                                ])))))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 31.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 17.h, top: 32.v, bottom: 11.v),
            onTap: () {
              onTapArrowLeft(context);
            }),
        title: AppbarTitle(
            text: "lbl_edit_profile2".tr,
            margin: EdgeInsets.only(left: 40.h, top: 23.v)),
        styleType: Style.bgFill);
  }

  /// Section Widget
  Widget _buildEmail(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(left: 10.h, right: 22.h),
        child: BlocSelector<ProfilePageBloc, ProfilePageState,
                TextEditingController?>(
            selector: (state) => state.emailController,
            builder: (context, emailController) {
              return CustomTextFormField(
                  controller: emailController,
                  hintText: "lbl_email".tr,
                  textInputType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null ||
                        (!isValidEmail(value, isRequired: true))) {
                      return "err_msg_please_enter_valid_email".tr;
                    }
                    return null;
                  },
                  contentPadding: EdgeInsets.symmetric(horizontal: 30.h));
            }));
  }

  /// Section Widget
  Widget _buildPassword(BuildContext context) {
    return Padding(
        padding: EdgeInsets.only(left: 10.h, right: 22.h),
        child: BlocSelector<ProfilePageBloc, ProfilePageState,
                TextEditingController?>(
            selector: (state) => state.passwordController,
            builder: (context, passwordController) {
              return CustomTextFormField(
                  controller: passwordController,
                  hintText: "lbl_password".tr,
                  textInputAction: TextInputAction.done,
                  textInputType: TextInputType.visiblePassword,
                  validator: (value) {
                    if (value == null ||
                        (!isValidPassword(value, isRequired: true))) {
                      return "err_msg_please_enter_valid_password".tr;
                    }
                    return null;
                  },
                  obscureText: true,
                  contentPadding: EdgeInsets.symmetric(horizontal: 30.h));
            }));
  }

  /// Section Widget
  Widget _buildCANCEL(BuildContext context) {
    return CustomElevatedButton(
        height: 44.v,
        width: 100.h,
        text: "lbl_cancel".tr,
        buttonStyle: CustomButtonStyles.fillPrimaryTL20,
        buttonTextStyle: theme.textTheme.bodyMedium!);
  }

  /// Section Widget
  Widget _buildSAVE(BuildContext context) {
    return CustomElevatedButton(
        height: 44.v,
        width: 100.h,
        text: "lbl_save".tr,
        buttonStyle: CustomButtonStyles.fillPrimaryTL20,
        buttonTextStyle: theme.textTheme.bodyMedium!);
  }

  /// Navigates to the previous screen.
  onTapArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }
}
