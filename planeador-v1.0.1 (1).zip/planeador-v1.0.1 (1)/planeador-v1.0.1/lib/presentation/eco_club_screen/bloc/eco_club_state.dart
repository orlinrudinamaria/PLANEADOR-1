// ignore_for_file: must_be_immutable

part of 'eco_club_bloc.dart';

/// Represents the state of EcoClub in the application.
class EcoClubState extends Equatable {
  EcoClubState({this.ecoClubModelObj});

  EcoClubModel? ecoClubModelObj;

  @override
  List<Object?> get props => [
        ecoClubModelObj,
      ];

  EcoClubState copyWith({EcoClubModel? ecoClubModelObj}) {
    return EcoClubState(
      ecoClubModelObj: ecoClubModelObj ?? this.ecoClubModelObj,
    );
  }
}
