import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/ecoclub_item_model.dart';
import 'package:planeador/presentation/eco_club_screen/models/eco_club_model.dart';
part 'eco_club_event.dart';
part 'eco_club_state.dart';

/// A bloc that manages the state of a EcoClub according to the event that is dispatched to it.
class EcoClubBloc extends Bloc<EcoClubEvent, EcoClubState> {
  EcoClubBloc(EcoClubState initialState) : super(initialState) {
    on<EcoClubInitialEvent>(_onInitialize);
  }

  _onInitialize(
    EcoClubInitialEvent event,
    Emitter<EcoClubState> emit,
  ) async {
    emit(state.copyWith(
        ecoClubModelObj: state.ecoClubModelObj
            ?.copyWith(ecoclubItemList: fillEcoclubItemList())));
  }

  List<EcoclubItemModel> fillEcoclubItemList() {
    return [
      EcoclubItemModel(
          image: ImageConstant.imgRectangle263,
          eventDateXxXxXxxx: "Event date:xx/xx/xxxx\nTime:\nVenue:\nForm:"),
      EcoclubItemModel(
          image: ImageConstant.imgRectangle272,
          eventDateXxXxXxxx: "Event date:xx/xx/xxxx\nTime:\nVenue:\nForm:"),
      EcoclubItemModel(
          image: ImageConstant.imgRectangle282,
          eventDateXxXxXxxx: "Event date:xx/xx/xxxx\nTime:\nVenue:\nForm:"),
      EcoclubItemModel(
          image: ImageConstant.imgRectangle302,
          eventDateXxXxXxxx: "Event date:xx/xx/xxxx\nTime:\nVenue:\nForm:"),
      EcoclubItemModel(
          image: ImageConstant.imgRectangle312,
          eventDateXxXxXxxx: "Event date:xx/xx/xxxx\nTime:\nVenue:\nForm:"),
      EcoclubItemModel(
          image: ImageConstant.imgRectangle322,
          eventDateXxXxXxxx: "Event date:xx/xx/xxxx\nTime:\nVenue:\nForm:")
    ];
  }
}
