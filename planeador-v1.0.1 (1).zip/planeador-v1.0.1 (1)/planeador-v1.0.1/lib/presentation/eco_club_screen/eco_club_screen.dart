import 'package:planeador/widgets/app_bar/custom_app_bar.dart';
import 'package:planeador/widgets/app_bar/appbar_leading_image.dart';
import 'package:planeador/widgets/app_bar/appbar_subtitle.dart';
import 'widgets/ecoclub_item_widget.dart';
import 'models/ecoclub_item_model.dart';
import 'models/eco_club_model.dart';
import 'package:flutter/material.dart';
import 'package:planeador/core/app_export.dart';
import 'bloc/eco_club_bloc.dart';

class EcoClubScreen extends StatelessWidget {
  const EcoClubScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<EcoClubBloc>(
        create: (context) =>
            EcoClubBloc(EcoClubState(ecoClubModelObj: EcoClubModel()))
              ..add(EcoClubInitialEvent()),
        child: EcoClubScreen());
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(context),
            body: Padding(
                padding: EdgeInsets.only(left: 37.h, top: 54.v, right: 26.h),
                child: BlocSelector<EcoClubBloc, EcoClubState, EcoClubModel?>(
                    selector: (state) => state.ecoClubModelObj,
                    builder: (context, ecoClubModelObj) {
                      return ListView.separated(
                          physics: BouncingScrollPhysics(),
                          shrinkWrap: true,
                          separatorBuilder: (context, index) {
                            return SizedBox(height: 25.v);
                          },
                          itemCount:
                              ecoClubModelObj?.ecoclubItemList.length ?? 0,
                          itemBuilder: (context, index) {
                            EcoclubItemModel model =
                                ecoClubModelObj?.ecoclubItemList[index] ??
                                    EcoclubItemModel();
                            return EcoclubItemWidget(model);
                          });
                    }))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 37.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 23.h, top: 32.v, bottom: 11.v),
            onTap: () {
              onTapArrowLeft(context);
            }),
        centerTitle: true,
        title: AppbarSubtitle(text: "lbl_brochure".tr),
        styleType: Style.bgFill);
  }

  /// Navigates to the previous screen.
  onTapArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }
}
