import 'models/frame_two_model.dart';
import 'package:flutter/material.dart';
import 'package:planeador/core/app_export.dart';
import 'bloc/frame_two_bloc.dart';

class FrameTwoScreen extends StatelessWidget {
  const FrameTwoScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<FrameTwoBloc>(
        create: (context) =>
            FrameTwoBloc(FrameTwoState(frameTwoModelObj: FrameTwoModel()))
              ..add(FrameTwoInitialEvent()),
        child: FrameTwoScreen());
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<FrameTwoBloc, FrameTwoState>(builder: (context, state) {
      return SafeArea(
          child: Scaffold(
              body: SizedBox(
                  width: double.maxFinite,
                  child: Column(children: [
                    SizedBox(height: 31.v),
                    Expanded(
                        child: SingleChildScrollView(
                            child: Container(
                                height: 1038.v,
                                width: 284.h,
                                margin: EdgeInsets.only(
                                    left: 34.h, right: 42.h, bottom: 31.v),
                                child: Stack(
                                    alignment: Alignment.topLeft,
                                    children: [
                                      Align(
                                          alignment: Alignment.center,
                                          child: SizedBox(
                                              width: 277.h,
                                              child: RichText(
                                                  text: TextSpan(children: [
                                                    TextSpan(
                                                        text: "lbl_help_center"
                                                            .tr,
                                                        style: CustomTextStyles
                                                            .titleLargeffffffff),
                                                    TextSpan(
                                                        text:
                                                            "msg_welcome_to_planeador_s"
                                                                .tr,
                                                        style: CustomTextStyles
                                                            .titleLargeffffffffRegular),
                                                    TextSpan(
                                                        text: "lbl_faq".tr,
                                                        style: CustomTextStyles
                                                            .bodyLarge18),
                                                    TextSpan(
                                                        text:
                                                            "msg_1_how_to_update"
                                                                .tr,
                                                        style: CustomTextStyles
                                                            .bodyMediumffffffff),
                                                    TextSpan(
                                                        text:
                                                            "lbl_privacy_policy2"
                                                                .tr,
                                                        style: CustomTextStyles
                                                            .bodyLarge18),
                                                    TextSpan(
                                                        text:
                                                            "msg_at_planeador_we"
                                                                .tr,
                                                        style: CustomTextStyles
                                                            .bodyMediumffffffff),
                                                    TextSpan(
                                                        text:
                                                            "msg_what_information"
                                                                .tr,
                                                        style: CustomTextStyles
                                                            .bodyLarge18),
                                                    TextSpan(
                                                        text:
                                                            "msg_account_information"
                                                                .tr,
                                                        style: theme.textTheme
                                                            .bodyLarge),
                                                    TextSpan(
                                                        text:
                                                            "msg_when_you_sign_up"
                                                                .tr,
                                                        style: CustomTextStyles
                                                            .bodyMediumffffffff),
                                                    TextSpan(
                                                        text:
                                                            "msg_event_information"
                                                                .tr,
                                                        style: theme.textTheme
                                                            .bodyLarge),
                                                    TextSpan(
                                                        text:
                                                            "msg_when_you_create"
                                                                .tr,
                                                        style: CustomTextStyles
                                                            .bodyMediumffffffff),
                                                    TextSpan(
                                                        text:
                                                            "lbl_usage_data".tr,
                                                        style: theme.textTheme
                                                            .bodyLarge),
                                                    TextSpan(
                                                        text:
                                                            "msg_we_collect_data"
                                                                .tr,
                                                        style: CustomTextStyles
                                                            .bodyMediumffffffff),
                                                    TextSpan(
                                                        text:
                                                            "lbl_contact_us".tr,
                                                        style: theme.textTheme
                                                            .titleMedium),
                                                    TextSpan(
                                                        text:
                                                            "msg_need_assistance"
                                                                .tr,
                                                        style: CustomTextStyles
                                                            .bodyMediumffffffff),
                                                    TextSpan(
                                                        text:
                                                            "lbl_email_support"
                                                                .tr,
                                                        style: CustomTextStyles
                                                            .titleSmallffffffff),
                                                    TextSpan(
                                                        text:
                                                            "msg_for_non_urgent_inquiries"
                                                                .tr,
                                                        style: CustomTextStyles
                                                            .bodyMediumffffffff),
                                                    TextSpan(
                                                        text:
                                                            "msg_community_forums_engage"
                                                                .tr,
                                                        style: CustomTextStyles
                                                            .titleSmallffffffff)
                                                  ]),
                                                  textAlign: TextAlign.left))),
                                      CustomImageView(
                                          imagePath: ImageConstant.imgArrowLeft,
                                          height: 21.v,
                                          width: 14.h,
                                          alignment: Alignment.topLeft,
                                          onTap: () {
                                            onTapImgArrowLeft(context);
                                          })
                                    ]))))
                  ]))));
    });
  }

  /// Navigates to the previous screen.
  onTapImgArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }
}
