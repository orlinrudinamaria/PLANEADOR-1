// ignore_for_file: must_be_immutable

part of 'fine_arts_bloc.dart';

/// Represents the state of FineArts in the application.
class FineArtsState extends Equatable {
  FineArtsState({this.fineArtsModelObj});

  FineArtsModel? fineArtsModelObj;

  @override
  List<Object?> get props => [
        fineArtsModelObj,
      ];

  FineArtsState copyWith({FineArtsModel? fineArtsModelObj}) {
    return FineArtsState(
      fineArtsModelObj: fineArtsModelObj ?? this.fineArtsModelObj,
    );
  }
}
