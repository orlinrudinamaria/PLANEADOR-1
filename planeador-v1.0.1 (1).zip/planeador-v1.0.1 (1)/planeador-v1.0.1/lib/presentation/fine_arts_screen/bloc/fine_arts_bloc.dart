import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/finearts_item_model.dart';
import 'package:planeador/presentation/fine_arts_screen/models/fine_arts_model.dart';
part 'fine_arts_event.dart';
part 'fine_arts_state.dart';

/// A bloc that manages the state of a FineArts according to the event that is dispatched to it.
class FineArtsBloc extends Bloc<FineArtsEvent, FineArtsState> {
  FineArtsBloc(FineArtsState initialState) : super(initialState) {
    on<FineArtsInitialEvent>(_onInitialize);
  }

  _onInitialize(
    FineArtsInitialEvent event,
    Emitter<FineArtsState> emit,
  ) async {
    emit(state.copyWith(
        fineArtsModelObj: state.fineArtsModelObj
            ?.copyWith(fineartsItemList: fillFineartsItemList())));
  }

  List<FineartsItemModel> fillFineartsItemList() {
    return [
      FineartsItemModel(
          image: ImageConstant.imgRectangle26122x152,
          time:
              "Event date:xx/xx/xxxx\nTime: 1:00 pm\nVenue: Auditorium\nForm: "),
      FineartsItemModel(
          image: ImageConstant.imgRectangle27,
          time:
              "Event date:xx/xx/xxxx\nTime: 2:00 pm\nVenue: Auditorium\nForm:"),
      FineartsItemModel(
          image: ImageConstant.imgRectangle28,
          time: "Event date:xx/xx/xxxx\nTime:\nVenue: Auditorium\nForm:"),
      FineartsItemModel(
          image: ImageConstant.imgRectangle29,
          time: "Event date:xx/xx/xxxx\nTime:\nVenue: Auditorium\n Form:"),
      FineartsItemModel(
          image: ImageConstant.imgRectangle30,
          time: "Event date:xx/xx/xxxx\nTime: \nVenue: Auditorium\nForm:"),
      FineartsItemModel(
          image: ImageConstant.imgRectangle31,
          time: "Event date:xx/xx/xxxx\nTime:\nVenue: Auditorium\nForm:"),
      FineartsItemModel(
          image: ImageConstant.imgRectangle32,
          time: "Event date:xx/xx/xxxx\nTime:\nVenue: Auditorium\nForm:")
    ];
  }
}
