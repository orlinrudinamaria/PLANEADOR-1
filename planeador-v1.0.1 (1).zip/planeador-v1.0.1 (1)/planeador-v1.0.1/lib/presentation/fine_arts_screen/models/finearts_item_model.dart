import '../../../core/app_export.dart';

/// This class is used in the [finearts_item_widget] screen.
class FineartsItemModel {
  FineartsItemModel({
    this.image,
    this.time,
    this.id,
  }) {
    image = image ?? ImageConstant.imgRectangle26122x152;
    time = time ??
        "Event date:xx/xx/xxxx\nTime: 1:00 pm\nVenue: Auditorium\nForm: ";
    id = id ?? "";
  }

  String? image;

  String? time;

  String? id;
}
