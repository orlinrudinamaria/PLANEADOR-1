// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';
import '../../../core/app_export.dart';
import 'finearts_item_model.dart';

/// This class defines the variables used in the [fine_arts_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class FineArtsModel extends Equatable {
  FineArtsModel({this.fineartsItemList = const []}) {}

  List<FineartsItemModel> fineartsItemList;

  FineArtsModel copyWith({List<FineartsItemModel>? fineartsItemList}) {
    return FineArtsModel(
      fineartsItemList: fineartsItemList ?? this.fineartsItemList,
    );
  }

  @override
  List<Object?> get props => [fineartsItemList];
}
