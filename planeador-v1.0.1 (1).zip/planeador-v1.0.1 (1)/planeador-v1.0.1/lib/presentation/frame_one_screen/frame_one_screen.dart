import 'package:planeador/widgets/app_bar/custom_app_bar.dart';
import 'package:planeador/widgets/app_bar/appbar_leading_image.dart';
import 'package:planeador/widgets/app_bar/appbar_subtitle.dart';
import 'package:planeador/widgets/custom_elevated_button.dart';
import 'models/frame_one_model.dart';
import 'package:flutter/material.dart';
import 'package:planeador/core/app_export.dart';
import 'bloc/frame_one_bloc.dart';

class FrameOneScreen extends StatelessWidget {
  const FrameOneScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<FrameOneBloc>(
        create: (context) =>
            FrameOneBloc(FrameOneState(frameOneModelObj: FrameOneModel()))
              ..add(FrameOneInitialEvent()),
        child: FrameOneScreen());
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<FrameOneBloc, FrameOneState>(builder: (context, state) {
      return SafeArea(
          child: Scaffold(
              appBar: _buildAppBar(context),
              body: Container(
                  width: double.maxFinite,
                  padding:
                      EdgeInsets.symmetric(horizontal: 36.h, vertical: 15.v),
                  child: Column(children: [
                    Container(
                        height: 93.v,
                        width: 98.h,
                        padding: EdgeInsets.all(8.h),
                        decoration: AppDecoration.fillGray.copyWith(
                            borderRadius: BorderRadiusStyle.roundedBorder46),
                        child: CustomImageView(
                            imagePath: ImageConstant.imgAddImage,
                            height: 76.v,
                            width: 81.h,
                            radius: BorderRadius.circular(32.h),
                            alignment: Alignment.center)),
                    SizedBox(height: 9.v),
                    Text("lbl_add_image".tr, style: theme.textTheme.labelLarge),
                    SizedBox(height: 31.v),
                    Padding(
                        padding: EdgeInsets.only(right: 7.h),
                        child: _buildSixtyThree(context,
                            venue: "lbl_event_name".tr)),
                    SizedBox(height: 15.v),
                    Padding(
                        padding: EdgeInsets.only(right: 7.h),
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(children: [
                                Text("lbl_event_date".tr,
                                    style: theme.textTheme.titleSmall),
                                SizedBox(height: 11.v),
                                Text("lbl_event_time".tr,
                                    style: theme.textTheme.titleSmall)
                              ]),
                              Padding(
                                  padding:
                                      EdgeInsets.only(top: 13.v, bottom: 3.v),
                                  child: Column(children: [
                                    SizedBox(width: 188.h, child: Divider()),
                                    SizedBox(height: 29.v),
                                    SizedBox(width: 188.h, child: Divider())
                                  ]))
                            ])),
                    SizedBox(height: 15.v),
                    Padding(
                        padding: EdgeInsets.only(right: 7.h),
                        child:
                            _buildSixtyThree(context, venue: "lbl_venue".tr)),
                    SizedBox(height: 16.v),
                    Padding(
                        padding: EdgeInsets.only(right: 7.h),
                        child: _buildSixtyThree(context,
                            venue: "lbl_organizer".tr)),
                    Spacer(),
                    SizedBox(height: 68.v),
                    CustomElevatedButton(
                        text: "lbl_submit".tr,
                        margin: EdgeInsets.only(left: 17.h, right: 22.h))
                  ]))));
    });
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 26.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 12.h, top: 30.v, bottom: 13.v),
            onTap: () {
              onTapArrowLeft(context);
            }),
        centerTitle: true,
        title: AppbarSubtitle(text: "lbl_add_event2".tr),
        styleType: Style.bgFill);
  }

  /// Common widget
  Widget _buildSixtyThree(
    BuildContext context, {
    required String venue,
  }) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(venue,
          style: theme.textTheme.titleSmall!
              .copyWith(color: theme.colorScheme.onErrorContainer)),
      Padding(
          padding: EdgeInsets.only(top: 13.v, bottom: 3.v),
          child: SizedBox(width: 188.h, child: Divider()))
    ]);
  }

  /// Navigates to the previous screen.
  onTapArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }
}
