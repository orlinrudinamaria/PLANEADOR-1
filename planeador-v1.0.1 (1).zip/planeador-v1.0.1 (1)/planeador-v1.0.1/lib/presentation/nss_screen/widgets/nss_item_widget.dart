import '../models/nss_item_model.dart';
import 'package:flutter/material.dart';
import 'package:planeador/core/app_export.dart';

// ignore: must_be_immutable
class NssItemWidget extends StatelessWidget {
  NssItemWidget(
    this.nssItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  NssItemModel nssItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomImageView(
          imagePath: nssItemModelObj?.image,
          height: 122.v,
          width: 152.h,
        ),
        Container(
          width: 138.h,
          margin: EdgeInsets.only(
            left: 18.h,
            top: 7.v,
            bottom: 43.v,
          ),
          child: Text(
            nssItemModelObj.eventDateXxXxXxxx!,
            maxLines: 4,
            overflow: TextOverflow.ellipsis,
            style: theme.textTheme.titleSmall,
          ),
        ),
      ],
    );
  }
}
