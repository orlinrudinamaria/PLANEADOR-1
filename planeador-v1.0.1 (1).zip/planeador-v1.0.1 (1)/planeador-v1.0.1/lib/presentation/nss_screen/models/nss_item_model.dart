import '../../../core/app_export.dart';

/// This class is used in the [nss_item_widget] screen.
class NssItemModel {
  NssItemModel({
    this.image,
    this.eventDateXxXxXxxx,
    this.id,
  }) {
    image = image ?? ImageConstant.imgRectangle261;
    eventDateXxXxXxxx =
        eventDateXxXxXxxx ?? "Event date:xx/xx/xxxx\nTime:\nVenue:\nForm:";
    id = id ?? "";
  }

  String? image;

  String? eventDateXxXxXxxx;

  String? id;
}
