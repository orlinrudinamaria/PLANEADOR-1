import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/nss_item_model.dart';
import 'package:planeador/presentation/nss_screen/models/nss_model.dart';
part 'nss_event.dart';
part 'nss_state.dart';

/// A bloc that manages the state of a Nss according to the event that is dispatched to it.
class NssBloc extends Bloc<NssEvent, NssState> {
  NssBloc(NssState initialState) : super(initialState) {
    on<NssInitialEvent>(_onInitialize);
  }

  _onInitialize(
    NssInitialEvent event,
    Emitter<NssState> emit,
  ) async {
    emit(state.copyWith(
        nssModelObj:
            state.nssModelObj?.copyWith(nssItemList: fillNssItemList())));
  }

  List<NssItemModel> fillNssItemList() {
    return [
      NssItemModel(
          image: ImageConstant.imgRectangle261,
          eventDateXxXxXxxx: "Event date:xx/xx/xxxx\nTime:\nVenue:\nForm:"),
      NssItemModel(
          image: ImageConstant.imgRectangle27122x152,
          eventDateXxXxXxxx: "Event date:xx/xx/xxxx\nTime:\nVenue:\nForm:"),
      NssItemModel(
          image: ImageConstant.imgRectangle28122x152,
          eventDateXxXxXxxx: "Event date:xx/xx/xxxx\nTime:\nVenue:\nForm:"),
      NssItemModel(
          image: ImageConstant.imgRectangle29122x152,
          eventDateXxXxXxxx: "Event date:xx/xx/xxxx\nTime:\nVenue:\nForm:"),
      NssItemModel(
          image: ImageConstant.imgRectangle30122x152,
          eventDateXxXxXxxx: "Event date:xx/xx/xxxx\nTime:\nVenue:\nForm:")
    ];
  }
}
