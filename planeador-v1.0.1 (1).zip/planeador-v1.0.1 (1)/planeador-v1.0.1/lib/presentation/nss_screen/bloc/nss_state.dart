// ignore_for_file: must_be_immutable

part of 'nss_bloc.dart';

/// Represents the state of Nss in the application.
class NssState extends Equatable {
  NssState({this.nssModelObj});

  NssModel? nssModelObj;

  @override
  List<Object?> get props => [
        nssModelObj,
      ];

  NssState copyWith({NssModel? nssModelObj}) {
    return NssState(
      nssModelObj: nssModelObj ?? this.nssModelObj,
    );
  }
}
