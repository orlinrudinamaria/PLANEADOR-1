import 'package:planeador/widgets/app_bar/custom_app_bar.dart';
import 'package:planeador/widgets/app_bar/appbar_leading_image.dart';
import 'package:planeador/widgets/app_bar/appbar_subtitle.dart';
import 'package:planeador/widgets/custom_elevated_button.dart';
import 'models/frame_four_model.dart';
import 'package:flutter/material.dart';
import 'package:planeador/core/app_export.dart';
import 'bloc/frame_four_bloc.dart';

class FrameFourScreen extends StatelessWidget {
  const FrameFourScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<FrameFourBloc>(
        create: (context) =>
            FrameFourBloc(FrameFourState(frameFourModelObj: FrameFourModel()))
              ..add(FrameFourInitialEvent()),
        child: FrameFourScreen());
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<FrameFourBloc, FrameFourState>(
        builder: (context, state) {
      return SafeArea(
          child: Scaffold(
              appBar: _buildAppBar(context),
              body: Container(
                  width: double.maxFinite,
                  padding:
                      EdgeInsets.symmetric(horizontal: 34.h, vertical: 27.v),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Align(
                            alignment: Alignment.center,
                            child: Container(
                                height: 93.v,
                                width: 98.h,
                                padding: EdgeInsets.all(8.h),
                                decoration: AppDecoration.fillGray.copyWith(
                                    borderRadius:
                                        BorderRadiusStyle.roundedBorder46),
                                child: CustomImageView(
                                    imagePath: ImageConstant.imgAddImage,
                                    height: 76.v,
                                    width: 81.h,
                                    radius: BorderRadius.circular(32.h),
                                    alignment: Alignment.center))),
                        SizedBox(height: 9.v),
                        Align(
                            alignment: Alignment.center,
                            child: Text("lbl_club_logo".tr,
                                style: theme.textTheme.labelLarge)),
                        SizedBox(height: 31.v),
                        Text("lbl_club_name".tr,
                            style: theme.textTheme.titleSmall),
                        Align(
                            alignment: Alignment.centerRight,
                            child: SizedBox(
                                width: 199.h, child: Divider(endIndent: 11.h))),
                        SizedBox(height: 20.v),
                        Padding(
                            padding: EdgeInsets.only(right: 11.h),
                            child: _buildFortyFive(context,
                                motto: "lbl_incharge".tr)),
                        SizedBox(height: 10.v),
                        Padding(
                            padding: EdgeInsets.only(right: 11.h),
                            child: _buildFortyFive(context,
                                motto: "msg_motto".tr)),
                        SizedBox(height: 14.v),
                        Padding(
                            padding: EdgeInsets.only(right: 11.h),
                            child: Row(children: [
                              Text("lbl_president".tr,
                                  style: theme.textTheme.titleSmall),
                              Padding(
                                  padding:
                                      EdgeInsets.only(top: 13.v, bottom: 3.v),
                                  child: SizedBox(
                                      width: 197.h,
                                      child: Divider(indent: 9.h)))
                            ])),
                        Spacer(),
                        SizedBox(height: 56.v),
                        CustomElevatedButton(
                            text: "lbl_add".tr,
                            margin: EdgeInsets.only(left: 19.h, right: 24.h),
                            alignment: Alignment.center)
                      ]))));
    });
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: 26.h,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 12.h, top: 30.v, bottom: 13.v),
            onTap: () {
              onTapArrowLeft(context);
            }),
        centerTitle: true,
        title: AppbarSubtitle(text: "lbl_add_club2".tr),
        styleType: Style.bgFill);
  }

  /// Common widget
  Widget _buildFortyFive(
    BuildContext context, {
    required String motto,
  }) {
    return Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Text(motto,
          style: theme.textTheme.titleSmall!
              .copyWith(color: theme.colorScheme.onErrorContainer)),
      Padding(
          padding: EdgeInsets.only(top: 13.v, bottom: 3.v),
          child: SizedBox(width: 188.h, child: Divider()))
    ]);
  }

  /// Navigates to the previous screen.
  onTapArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }
}
