import 'package:planeador/widgets/custom_elevated_button.dart';
import 'models/welcome_model.dart';
import 'package:flutter/material.dart';
import 'package:planeador/core/app_export.dart';
import 'bloc/welcome_bloc.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<WelcomeBloc>(
        create: (context) =>
            WelcomeBloc(WelcomeState(welcomeModelObj: WelcomeModel()))
              ..add(WelcomeInitialEvent()),
        child: WelcomeScreen());
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<WelcomeBloc, WelcomeState>(builder: (context, state) {
      return SafeArea(
          child: Scaffold(
              body: Container(
                  width: double.maxFinite,
                  padding: EdgeInsets.symmetric(horizontal: 52.h),
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomImageView(
                            imagePath: ImageConstant.imgObject11,
                            height: 196.v,
                            width: 222.h),
                        SizedBox(height: 67.v),
                        CustomImageView(
                            imagePath: ImageConstant.imgCalt1,
                            height: 72.v,
                            width: 193.h),
                        SizedBox(height: 54.v),
                        Align(
                            alignment: Alignment.centerRight,
                            child: Text("msg_let_s_explore_for".tr,
                                style:
                                    CustomTextStyles.titleLargeGray100Regular)),
                        SizedBox(height: 26.v),
                        CustomElevatedButton(
                            height: 45.v,
                            text: "lbl_get_started".tr,
                            margin: EdgeInsets.only(left: 4.h, right: 3.h),
                            onPressed: () {
                              onTapGetStarted(context);
                            }),
                        SizedBox(height: 5.v)
                      ]))));
    });
  }

  /// Navigates to the loginPageScreen when the action is triggered.
  onTapGetStarted(BuildContext context) {
    NavigatorService.pushNamed(
      AppRoutes.loginPageScreen,
    );
  }
}
